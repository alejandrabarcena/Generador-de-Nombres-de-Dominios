export default {
  base: '/Generador-de-Nombres-de-Dominios/',
};
